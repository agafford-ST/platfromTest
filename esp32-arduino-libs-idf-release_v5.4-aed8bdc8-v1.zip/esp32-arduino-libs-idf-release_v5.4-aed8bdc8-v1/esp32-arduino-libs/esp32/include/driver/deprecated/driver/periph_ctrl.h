/*
 * SPDX-FileCopyrightText: 2015-2021 Espressif Systems (Shanghai) CO LTD
 *
 * SPDX-License-Identifier: Apache-2.0
 */
#pragma once
#warning driver/periph_ctrl.h header is no longer used, and will be removed in future versions.
#include "esp_private/periph_ctrl.h"
