/*
 * SPDX-FileCopyrightText: 2015-2022 Espressif Systems (Shanghai) CO LTD
 *
 * SPDX-License-Identifier: Apache-2.0
 */
#pragma once
#warning driver/rtc_cntl.h header is no longer used, and will be removed in future versions.
#include "esp_private/rtc_ctrl.h"
