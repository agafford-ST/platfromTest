#pragma once

#include <sdkconfig.h>

#define HAVE_LWIP_UDP_BIND_NETIF 1
